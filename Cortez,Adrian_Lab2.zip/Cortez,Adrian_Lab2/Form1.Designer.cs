﻿namespace Cortez_Adrian_Lab2
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            txtCommonName = new TextBox();
            txtRegisteredName = new TextBox();
            txtBreed = new TextBox();
            txtSize = new TextBox();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            txtYearOfBirth = new TextBox();
            btnSubmit = new Button();
            txtVacCode = new TextBox();
            txtVacDate = new TextBox();
            txtVacPerson = new TextBox();
            text = new Label();
            label7 = new Label();
            label = new Label();
            btnAddVac = new Button();
            labelnew = new Label();
            txtColor = new TextBox();
            labe98 = new Label();
            label99 = new Label();
            label10 = new Label();
            txtTraining = new TextBox();
            txtWeight = new TextBox();
            txtBirthDate = new TextBox();
            radioHorse = new RadioButton();
            radioDog = new RadioButton();
            txtDisplay = new RichTextBox();
            fontDialog1 = new FontDialog();
            label8 = new Label();
            animalsBox = new GroupBox();
            animalsBox.SuspendLayout();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(26, 22);
            label1.Name = "label1";
            label1.Size = new Size(157, 15);
            label1.TabIndex = 0;
            label1.Text = "Amish Gardens Horse Ranch";
            // 
            // txtCommonName
            // 
            txtCommonName.Location = new Point(24, 125);
            txtCommonName.Name = "txtCommonName";
            txtCommonName.Size = new Size(100, 23);
            txtCommonName.TabIndex = 2;
            // 
            // txtRegisteredName
            // 
            txtRegisteredName.Location = new Point(177, 125);
            txtRegisteredName.Name = "txtRegisteredName";
            txtRegisteredName.Size = new Size(100, 23);
            txtRegisteredName.TabIndex = 4;
            // 
            // txtBreed
            // 
            txtBreed.Location = new Point(24, 183);
            txtBreed.Name = "txtBreed";
            txtBreed.Size = new Size(100, 23);
            txtBreed.TabIndex = 6;
            // 
            // txtSize
            // 
            txtSize.Location = new Point(177, 183);
            txtSize.Name = "txtSize";
            txtSize.Size = new Size(100, 23);
            txtSize.TabIndex = 8;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(24, 107);
            label2.Name = "label2";
            label2.Size = new Size(39, 15);
            label2.TabIndex = 1;
            label2.Text = "Name";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(171, 107);
            label3.Name = "label3";
            label3.Size = new Size(131, 15);
            label3.TabIndex = 3;
            label3.Text = "Registered Horse Name";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(24, 165);
            label4.Name = "label4";
            label4.Size = new Size(37, 15);
            label4.TabIndex = 5;
            label4.Text = "Breed";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(177, 165);
            label5.Name = "label5";
            label5.Size = new Size(62, 15);
            label5.TabIndex = 7;
            label5.Text = "Size (HH.I)";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(177, 223);
            label6.Name = "label6";
            label6.Size = new Size(71, 15);
            label6.TabIndex = 9;
            label6.Text = "Year of Birth";
            // 
            // txtYearOfBirth
            // 
            txtYearOfBirth.Location = new Point(177, 241);
            txtYearOfBirth.Name = "txtYearOfBirth";
            txtYearOfBirth.Size = new Size(100, 23);
            txtYearOfBirth.TabIndex = 10;
            // 
            // btnSubmit
            // 
            btnSubmit.Location = new Point(24, 364);
            btnSubmit.Name = "btnSubmit";
            btnSubmit.Size = new Size(140, 45);
            btnSubmit.TabIndex = 11;
            btnSubmit.Text = "Submit";
            btnSubmit.UseVisualStyleBackColor = true;
            btnSubmit.Click += btnSubmit_Click;
            // 
            // txtVacCode
            // 
            txtVacCode.Location = new Point(555, 125);
            txtVacCode.Name = "txtVacCode";
            txtVacCode.Size = new Size(196, 23);
            txtVacCode.TabIndex = 16;
            // 
            // txtVacDate
            // 
            txtVacDate.Location = new Point(555, 183);
            txtVacDate.Name = "txtVacDate";
            txtVacDate.Size = new Size(196, 23);
            txtVacDate.TabIndex = 18;
            // 
            // txtVacPerson
            // 
            txtVacPerson.Location = new Point(555, 241);
            txtVacPerson.Name = "txtVacPerson";
            txtVacPerson.Size = new Size(196, 23);
            txtVacPerson.TabIndex = 20;
            // 
            // text
            // 
            text.AutoSize = true;
            text.Location = new Point(556, 107);
            text.Name = "text";
            text.Size = new Size(99, 15);
            text.TabIndex = 15;
            text.Text = "Vaccination Code";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(556, 165);
            label7.Name = "label7";
            label7.Size = new Size(182, 15);
            label7.TabIndex = 17;
            label7.Text = "Date of Vaccination (MM/DD/YY)";
            // 
            // label
            // 
            label.AutoSize = true;
            label.Location = new Point(556, 221);
            label.Name = "label";
            label.Size = new Size(144, 15);
            label.TabIndex = 19;
            label.Text = "Person Giving Vaccination";
            // 
            // btnAddVac
            // 
            btnAddVac.Location = new Point(556, 281);
            btnAddVac.Name = "btnAddVac";
            btnAddVac.Size = new Size(195, 37);
            btnAddVac.TabIndex = 21;
            btnAddVac.Text = "Add Vaccination";
            btnAddVac.UseVisualStyleBackColor = true;
            btnAddVac.Click += btnAddVac_Click;
            // 
            // labelnew
            // 
            labelnew.AutoSize = true;
            labelnew.Location = new Point(24, 221);
            labelnew.Name = "labelnew";
            labelnew.Size = new Size(36, 15);
            labelnew.TabIndex = 22;
            labelnew.Text = "Color";
            // 
            // txtColor
            // 
            txtColor.Location = new Point(26, 241);
            txtColor.Name = "txtColor";
            txtColor.Size = new Size(100, 23);
            txtColor.TabIndex = 23;
            // 
            // labe98
            // 
            labe98.AutoSize = true;
            labe98.Location = new Point(332, 107);
            labe98.Name = "labe98";
            labe98.Size = new Size(132, 15);
            labe98.TabIndex = 24;
            labe98.Text = "Birth Date (MM/DD/YY)";
            // 
            // label99
            // 
            label99.AutoSize = true;
            label99.Location = new Point(332, 165);
            label99.Name = "label99";
            label99.Size = new Size(45, 15);
            label99.TabIndex = 25;
            label99.Text = "Weight";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(332, 221);
            label10.Name = "label10";
            label10.Size = new Size(49, 15);
            label10.TabIndex = 26;
            label10.Text = "Training";
            // 
            // txtTraining
            // 
            txtTraining.Location = new Point(332, 241);
            txtTraining.Name = "txtTraining";
            txtTraining.Size = new Size(100, 23);
            txtTraining.TabIndex = 27;
            // 
            // txtWeight
            // 
            txtWeight.Location = new Point(332, 183);
            txtWeight.Name = "txtWeight";
            txtWeight.Size = new Size(100, 23);
            txtWeight.TabIndex = 28;
            // 
            // txtBirthDate
            // 
            txtBirthDate.Location = new Point(332, 125);
            txtBirthDate.Name = "txtBirthDate";
            txtBirthDate.Size = new Size(100, 23);
            txtBirthDate.TabIndex = 29;
            // 
            // radioHorse
            // 
            radioHorse.AutoSize = true;
            radioHorse.Location = new Point(15, 22);
            radioHorse.Name = "radioHorse";
            radioHorse.Size = new Size(56, 19);
            radioHorse.TabIndex = 30;
            radioHorse.TabStop = true;
            radioHorse.Text = "Horse";
            radioHorse.UseVisualStyleBackColor = true;
            radioHorse.CheckedChanged += radioHorse_CheckedChanged;
            // 
            // radioDog
            // 
            radioDog.AutoSize = true;
            radioDog.Location = new Point(15, 41);
            radioDog.Name = "radioDog";
            radioDog.Size = new Size(47, 19);
            radioDog.TabIndex = 31;
            radioDog.TabStop = true;
            radioDog.Text = "Dog";
            radioDog.UseVisualStyleBackColor = true;
            radioDog.CheckedChanged += radioDog_CheckedChanged;
            // 
            // txtDisplay
            // 
            txtDisplay.Location = new Point(835, 135);
            txtDisplay.Name = "txtDisplay";
            txtDisplay.Size = new Size(348, 354);
            txtDisplay.TabIndex = 32;
            txtDisplay.Text = "";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(837, 107);
            label8.Name = "label8";
            label8.Size = new Size(103, 15);
            label8.TabIndex = 33;
            label8.Text = "Current Inventory:";
            // 
            // animalsBox
            // 
            animalsBox.Controls.Add(radioHorse);
            animalsBox.Controls.Add(radioDog);
            animalsBox.Location = new Point(26, 40);
            animalsBox.Name = "animalsBox";
            animalsBox.Size = new Size(150, 64);
            animalsBox.TabIndex = 34;
            animalsBox.TabStop = false;
            animalsBox.Text = "Animals";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1293, 605);
            Controls.Add(animalsBox);
            Controls.Add(label8);
            Controls.Add(txtDisplay);
            Controls.Add(txtBirthDate);
            Controls.Add(txtWeight);
            Controls.Add(txtTraining);
            Controls.Add(label10);
            Controls.Add(label99);
            Controls.Add(labe98);
            Controls.Add(txtColor);
            Controls.Add(labelnew);
            Controls.Add(btnAddVac);
            Controls.Add(label);
            Controls.Add(label7);
            Controls.Add(text);
            Controls.Add(txtVacPerson);
            Controls.Add(txtVacDate);
            Controls.Add(txtVacCode);
            Controls.Add(btnSubmit);
            Controls.Add(txtYearOfBirth);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(txtSize);
            Controls.Add(txtBreed);
            Controls.Add(txtRegisteredName);
            Controls.Add(txtCommonName);
            Controls.Add(label1);
            Name = "Form1";
            Text = "Form1";
            animalsBox.ResumeLayout(false);
            animalsBox.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private TextBox txtCommonName;
        private TextBox txtRegisteredName;
        private TextBox txtBreed;
        private TextBox txtSize;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private TextBox txtYearOfBirth;
        private Button btnSubmit;
        private TextBox txtVacCode;
        private TextBox txtVacDate;
        private TextBox txtVacPerson;
        private Label text;
        private Label label7;
        private Label label;
        private Button btnAddVac;
        private Label labelnew;
        private TextBox txtColor;
        private Label labe98;
        private Label label99;
        private Label label10;
        private TextBox txtTraining;
        private TextBox txtWeight;
        private TextBox txtBirthDate;
        private RadioButton radioHorse;
        private RadioButton radioDog;
        private RichTextBox txtDisplay;
        private FontDialog fontDialog1;
        private Label label8;
        private GroupBox animalsBox;
    }
}